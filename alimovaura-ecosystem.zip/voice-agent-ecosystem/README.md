# Voice Agent Ecosystem

```
/android-agent      Kotlin + Compose app: always-on voice agent that operates the phone via AccessibilityService
/web-marketplace    index.html (GitHub Pages): white & gold storefront, UZ/RU/EN, wallet connect + buy
/smart-contracts    Marketplace.sol: USDT/USDC payments, emits AccessGranted, hasAccess() for licence checks
```

## How the pieces fit

1. Buyer pays on the website → `Marketplace.purchase()` → `AccessGranted(buyer, productId)`.
2. Website sees `hasAccess` → unlocks APK link + "Activate your phone".
3. App shows a **device code**; buyer pastes it on the site and signs it with the wallet → licence key `VA1.<chain>.<wallet>.<product>.<sig>`.
4. App verifies: ecrecover → matches wallet → `hasAccess(wallet, product)` via `eth_call`.
5. Voice loop: STT → `UiSnapshot` (accessibility tree, no screenshots) → Claude (forced tool call → JSON actions) → **PermissionGate** → `execute()`.

## Setup

**Contract** – deploy `Marketplace(treasury)`, then `setToken(usdt,true)`, `setToken(usdc,true)`, `addProduct("Voice Agent", 49_000000)` on each chain. Put the addresses in `web-marketplace/index.html` (`CONFIG`) and `android-agent/gradle.properties`. Verify the token addresses in `CONFIG` against the official issuers before launch.

**Website** – push to GitHub; the included workflow publishes `web-marketplace/` to Pages. Set `apkUrl` to your release asset.

**Android** – open `android-agent/` in Android Studio (it generates the Gradle wrapper), set properties, run. Enable the Accessibility service (Android 13+ sideloaded: App info → ⋮ → *Allow restricted settings*).

## Security notes (read before shipping)

- **Do not ship your Anthropic key in the APK.** Set `BRAIN_BASE_URL` to a small proxy that re-checks the licence on-chain, then forwards to `api.anthropic.com/v1/messages` with your key. That proxy is the only real licence enforcement; the in-app check can be patched out.
- The APK link on a static site is not secret. The licence, not the link, is the protection.
- The permission gate is enforced in code (`PermissionGate`), independent of the model. Screen text is treated as untrusted data in the system prompt (prompt-injection defence). Passwords and key-like strings are masked before leaving the phone.
- Google Play restricts AccessibilityService use; distribute by direct APK.

## Known limits / next steps

- Not compiled or deployed in the authoring environment: build, run `forge`/Hardhat tests and test on real devices (Telegram hold-to-record, `open_app` from background, OEM battery killers).
- Wake word is transcript matching; use Porcupine/openWakeWord for true low-power detection.
- Voice message via loudspeaker→microphone is lossy; consider sending a pre-rendered audio file instead.
- Gmail is driven through the Gmail app UI; a Gmail API (OAuth) module is a separate step.
- Confirm Uzbek support for your chosen ElevenLabs model/voice.
