plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("org.jetbrains.kotlin.plugin.serialization")
}

fun prop(name: String, default: String): String =
    providers.gradleProperty(name).orElse(default).get()

android {
    namespace = "com.voiceagent.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.voiceagent.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"

        buildConfigField("String", "POLYGON_CONTRACT", "\"${prop("POLYGON_CONTRACT", "0x0000000000000000000000000000000000000000")}\"")
        buildConfigField("String", "POLYGON_RPC", "\"${prop("POLYGON_RPC", "https://polygon-rpc.com")}\"")
        buildConfigField("String", "BNB_CONTRACT", "\"${prop("BNB_CONTRACT", "0x0000000000000000000000000000000000000000")}\"")
        buildConfigField("String", "BNB_RPC", "\"${prop("BNB_RPC", "https://bsc-dataseed.binance.org")}\"")
        buildConfigField("long", "PRODUCT_ID", "${prop("PRODUCT_ID", "1")}L")
        buildConfigField("String", "BRAIN_BASE_URL", "\"${prop("BRAIN_BASE_URL", "")}\"")
    }

    buildTypes {
        release {
            isMinifyEnabled = false // enable + add keep rules for web3j/BouncyCastle before shipping
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    packaging {
        resources.excludes += setOf(
            "META-INF/versions/**",
            "META-INF/DEPENDENCIES",
            "META-INF/LICENSE*",
            "META-INF/NOTICE*",
            "META-INF/AL2.0",
            "META-INF/LGPL2.1",
            "META-INF/INDEX.LIST",
        )
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.10.01")
    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.core:core-ktx:1.15.0")

    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.7.3")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")

    // Encrypted storage for API keys / licence
    implementation("androidx.security:security-crypto:1.1.0-alpha06")

    // secp256k1 recovery + keccak for wallet-signature licence check (no full web3j needed)
    implementation("org.web3j:crypto:4.8.7-android")
}
