package com.voiceagent.app.agent

import java.util.Locale

/** Tiny localisation helper for spoken phrases, recogniser/TTS locales and yes/no/stop words (uz / ru / en). */
object L10n {

    private val strings: Map<String, Map<String, String>> = mapOf(
        "confirm" to mapOf(
            "uz" to "Hozir bajaraymi?",
            "ru" to "Выполнить сейчас?",
            "en" to "Should I execute this now?",
        ),
        "cancelled" to mapOf("uz" to "Bekor qilindi.", "ru" to "Отменено.", "en" to "Cancelled."),
        "stopped" to mapOf("uz" to "To‘xtatildi.", "ru" to "Остановлено.", "en" to "Stopped."),
        "failed" to mapOf("uz" to "Bajarib bo‘lmadi.", "ru" to "Не удалось выполнить.", "en" to "I couldn’t do that."),
        "listening" to mapOf("uz" to "Eshitaman.", "ru" to "Слушаю.", "en" to "Listening."),
        "needLicense" to mapOf(
            "uz" to "Litsenziya topilmadi. Ilovani oching va litsenziya kalitini kiriting.",
            "ru" to "Лицензия не найдена. Откройте приложение и введите ключ.",
            "en" to "No valid licence. Open the app and enter your licence key.",
        ),
        "needA11y" to mapOf(
            "uz" to "Maxsus imkoniyatlar xizmatini yoqing.",
            "ru" to "Включите службу специальных возможностей.",
            "en" to "Please enable the Accessibility service.",
        ),
    )

    fun t(lang: String, key: String): String = strings[key]?.get(lang) ?: strings[key]?.get("en") ?: key

    fun locale(lang: String): Locale = when (lang) {
        "uz" -> Locale("uz", "UZ")
        "ru" -> Locale("ru", "RU")
        else -> Locale.US
    }

    /** BCP-47 tag for SpeechRecognizer. */
    fun tag(lang: String): String = locale(lang).toLanguageTag()

    private val yes = setOf(
        "yes", "yeah", "yep", "ok", "okay", "sure", "do it", "confirm",
        "ha", "xa", "ha albatta", "bajar", "bajaring", "mayli", "tasdiqlayman",
        "да", "давай", "выполняй", "подтверждаю", "конечно",
    )
    private val no = setOf(
        "no", "nope", "stop", "cancel", "don't", "do not",
        "yo‘q", "yo'q", "yoq", "yo`q", "bekor", "to‘xta", "to'xta", "toxta",
        "нет", "стоп", "отмена", "отмени", "не надо", "не нужно",
    )

    /** true = yes, false = no, null = not an answer. Strict on purpose: anything unclear is NOT a yes. */
    fun parseYesNo(raw: String): Boolean? {
        val s = raw.lowercase().trim().trim('.', '!', '?', ',')
        if (s in no || no.any { s.startsWith("$it ") }) return false
        if (s in yes || yes.any { s.startsWith("$it ") }) return true
        return null
    }

    private val stopWords = setOf("stop", "cancel", "to‘xta", "to'xta", "toxta", "bekor", "стоп", "отмена", "хватит")
    fun isStop(text: String): Boolean = text.lowercase().trim().trim('.', '!', '?', ',') in stopWords
}
