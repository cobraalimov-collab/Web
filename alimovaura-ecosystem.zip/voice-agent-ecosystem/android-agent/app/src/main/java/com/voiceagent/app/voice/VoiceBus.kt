package com.voiceagent.app.voice

import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import java.time.LocalTime
import java.time.format.DateTimeFormatter

/**
 * In-process event hub that decouples the listener service, the agent loop and the UI.
 * (Everything lives in one process, so plain flows are enough.)
 */
object VoiceBus {
    /** Every finished utterance, raw. Used for yes/no answers. */
    val transcripts = MutableSharedFlow<String>(extraBufferCapacity = 8, onBufferOverflow = BufferOverflow.DROP_OLDEST)

    /** Utterances that passed wake-word filtering (or are stop words): these start / stop tasks. */
    val commands = MutableSharedFlow<String>(extraBufferCapacity = 4, onBufferOverflow = BufferOverflow.DROP_OLDEST)

    /** True while we talk — the microphone is released so we never hear ourselves. */
    val speaking = MutableStateFlow(false)

    val listening = MutableStateFlow(false)
    val status = MutableStateFlow("Idle")

    /** Visible log box on the main screen: speech text, API status, exact error messages (newest last). */
    val logLines = MutableStateFlow<List<String>>(emptyList())
    private val timeFmt = DateTimeFormatter.ofPattern("HH:mm:ss")
    private const val MAX_LOG_LINES = 300

    /** Thread-safe. [tag] is e.g. MIC, TASK, API, ERR. */
    fun log(tag: String, message: String) {
        val line = "${LocalTime.now().format(timeFmt)} [$tag] $message"
        logLines.update { (it + line).takeLast(MAX_LOG_LINES) }
    }

    fun clearLog() { logLines.value = emptyList() }

    class Confirmation(
        val spoken: String,
        val detail: String,
        val answer: CompletableDeferred<Boolean>,
    )

    /** Non-null while the permission gate is waiting for the user's yes/no. */
    val confirmation = MutableStateFlow<Confirmation?>(null)
}
