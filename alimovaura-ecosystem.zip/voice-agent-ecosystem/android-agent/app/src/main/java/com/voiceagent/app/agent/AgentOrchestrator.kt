package com.voiceagent.app.agent

import android.content.Context
import com.voiceagent.app.accessibility.VoiceAgentAccessibilityService
import com.voiceagent.app.data.SecureStore
import com.voiceagent.app.license.LicenseManager
import com.voiceagent.app.voice.SpeechOutput
import com.voiceagent.app.voice.VoiceBus
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * The agent loop:   listen → observe screen → ask Claude → gate → act → repeat until done.
 *
 *   voice command ─▶ UiSnapshot ─▶ ClaudeBrainManager ─▶ [PermissionGate] ─▶ AccessibilityService.execute
 *                        ▲                                                            │
 *                        └──────────────── wait for UI to settle ◀────────────────────┘
 */
class AgentOrchestrator(appContext: Context, private val scope: CoroutineScope) {

    private val store = SecureStore.get(appContext)
    val speech = SpeechOutput(appContext, store)
    private val gate = PermissionGate(speech)
    private val license = LicenseManager(store)
    private var job: Job? = null

    /** Suspends forever, handling commands from the voice listener. */
    suspend fun run() {
        VoiceBus.commands.collect { onCommand(it) }
    }

    fun shutdown() {
        job?.cancel()
        speech.shutdown()
    }

    private fun onCommand(text: String) {
        if (L10n.isStop(text)) {
            job?.cancel() // voice kill-switch: also lifts a held finger (see hold_and_speak)
            return
        }
        if (job?.isActive == true) return // one task at a time
        job = scope.launch(Dispatchers.Default) { runGoal(text) }
    }

    private suspend fun runGoal(goal: String) {
        val lang = store.language
        VoiceBus.status.value = "Task: $goal"
        VoiceBus.log("TASK", "goal: “$goal”")
        try {
            if (!license.isValid()) { VoiceBus.log("ERR", "licence is not valid"); return say(lang, "needLicense") }
            val svc = VoiceAgentAccessibilityService.instance
                ?: run { VoiceBus.log("ERR", "accessibility service is not running"); return say(lang, "needA11y") }
            val brain = ClaudeBrainManager(BrainConfig.from(store))

            val history = ArrayList<String>()
            var lastSignature = ""
            var repeats = 0

            for (step in 1..MAX_STEPS) {
                svc.awaitSettled()
                val snap = svc.snapshot()
                if (snap == null) {
                    VoiceBus.log("ERR", "no screen content (rootInActiveWindow is null — protected screen or window not ready)")
                    delay(300); continue
                }

                VoiceBus.status.value = "Step $step · thinking…"
                var shot: ByteArray? = null
                if (store.sendScreenshot) {
                    shot = svc.screenshotJpeg { VoiceBus.log("ERR", "screenshot skipped: $it") }
                    if (shot != null) VoiceBus.log("API", "screenshot attached: ${shot.size / 1024} KB JPEG")
                }
                VoiceBus.log("TASK", "step $step: asking the model")
                val decision = brain.decide(goal, snap.text, history, lang, shot)
                decision.say?.takeIf { it.isNotBlank() }?.let { speech.speak(it) }

                // Stuck detection: the model keeps proposing the same thing.
                val signature = decision.actions.toString()
                repeats = if (signature == lastSignature && decision.actions.isNotEmpty()) repeats + 1 else 0
                lastSignature = signature
                if (repeats >= 2) return say(lang, "failed")

                var screenChanged = false
                for (action in decision.actions) {
                    if (screenChanged) break // remaining node ids refer to the old screen → re-observe first

                    val label = snap.label(action.node)
                    val detail = describe(action, label)

                    if (gate.requiresConfirmation(action, label)) {
                        VoiceBus.status.value = "Waiting for your confirmation…"
                        if (!gate.confirm(decision.confirmationPrompt, detail, lang)) return say(lang, "cancelled")
                    }

                    VoiceBus.status.value = "Step $step · $detail"
                    VoiceBus.log("TASK", "do: $detail")
                    val windowBefore = svc.windowVersion
                    val result = svc.execute(action, snap) { speech.speak(it) }
                    history += "$detail → " + if (result.ok) "ok (${result.detail})" else "FAILED: ${result.detail}"
                    if (!result.ok) VoiceBus.log("ERR", "action failed: ${result.detail}")

                    svc.awaitSettled()
                    if (svc.windowVersion != windowBefore) screenChanged = true
                    if (!result.ok) break // let the model re-plan with the failure in its history
                }

                if (decision.done) { VoiceBus.log("TASK", "done"); return }
            }
            VoiceBus.log("ERR", "gave up after $MAX_STEPS steps")
            say(lang, "failed")
        } catch (e: CancellationException) {
            VoiceBus.log("TASK", "stopped")
            withContext(NonCancellable) { speech.speak(L10n.t(lang, "stopped")) }
            throw e
        } catch (e: BrainException) {
            VoiceBus.status.value = "Brain error: ${e.message}"
            VoiceBus.log("ERR", "brain: ${e.message}")
            speech.speak(L10n.t(lang, "failed"))
        } catch (e: Exception) {
            VoiceBus.status.value = "Error: ${e.message}"
            VoiceBus.log("ERR", "${e.javaClass.simpleName}: ${e.message}")
            speech.speak(L10n.t(lang, "failed"))
        } finally {
            if (VoiceBus.status.value.startsWith("Task") || VoiceBus.status.value.startsWith("Step")) {
                VoiceBus.status.value = "Idle"
            }
        }
    }

    private suspend fun say(lang: String, key: String) = speech.speak(L10n.t(lang, key))

    private fun describe(a: AgentAction, label: String): String {
        val target = label.trim().take(40).let { if (it.isNotEmpty()) " «$it»" else "" }
        return when (a.type) {
            ActionType.TAP -> "tap #${a.node}$target"
            ActionType.TYPE -> "type “${a.text.orEmpty().take(60)}”${if (a.submit == true) " + send" else ""}"
            ActionType.OPEN_APP -> "open ${a.app}"
            ActionType.HOLD_AND_SPEAK -> "hold #${a.node}$target and speak “${a.text.orEmpty().take(80)}”"
            ActionType.COPY -> "copy #${a.node}$target to clipboard"
            ActionType.PASTE -> "paste${if (a.node != null) " into #${a.node}" else ""}"
            ActionType.SCROLL -> "scroll ${a.direction ?: "down"}"
            else -> a.type
        }
    }

    private companion object {
        const val MAX_STEPS = 25
    }
}
