package com.voiceagent.app.accessibility

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ClipData
import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.ColorSpace
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.os.PersistableBundle
import android.os.SystemClock
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.voiceagent.app.agent.ActionResult
import com.voiceagent.app.agent.ActionType
import com.voiceagent.app.agent.AgentAction
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import kotlin.coroutines.resume

/**
 * The agent's hands and eyes.
 *
 * Speed comes from never taking screenshots: the screen is read as an accessibility node tree and
 * actions are performed with ACTION_CLICK / ACTION_SET_TEXT / ACTION_SCROLL on the live nodes
 * (a few milliseconds each). Gestures are only a fallback or used for press-and-hold.
 *
 * This class performs whatever it is told. Deciding whether an action needs the user's permission
 * is done by [com.voiceagent.app.agent.PermissionGate] BEFORE execute() is called.
 */
class VoiceAgentAccessibilityService : AccessibilityService() {

    companion object {
        private val SETTINGS_WORDS = setOf(
            "settings", "setting", "android settings", "system settings", "android.settings.settings",
            "настройки", "настройка", "sozlamalar", "sozlama", "sozlash",
        )

        /** Spoken / typed name → candidate package ids (first installed one wins). */
        private val KNOWN_APPS: Map<String, List<String>> = buildMap {
            fun add(pkgs: List<String>, vararg names: String) = names.forEach { put(it, pkgs) }
            add(listOf("org.telegram.messenger", "org.telegram.messenger.web", "org.thunderdog.challegram"),
                "telegram", "telegramm", "телеграм", "телеграмм", "телега")
            add(listOf("com.android.chrome", "com.chrome.beta"), "chrome", "google chrome", "хром", "гугл хром", "браузер", "browser")
            add(listOf("com.whatsapp", "com.whatsapp.w4b"), "whatsapp", "ватсап", "вацап", "уотсап")
            add(listOf("com.google.android.gm"), "gmail", "gmail app", "почта", "gmeil", "jimeyl")
            add(listOf("com.google.android.youtube"), "youtube", "ютуб", "ютьюб")
            add(listOf("com.google.android.apps.maps"), "maps", "google maps", "карты", "xarita")
            add(listOf("com.android.vending"), "play store", "google play", "плей маркет", "play market")
            add(listOf("com.instagram.android"), "instagram", "инстаграм")
            add(listOf("com.google.android.dialer", "com.android.dialer", "com.samsung.android.dialer"), "phone", "dialer", "телефон", "telefon")
            add(listOf("com.google.android.apps.messaging", "com.samsung.android.messaging", "com.android.mms"), "messages", "sms", "сообщения", "xabarlar")
            add(listOf("com.android.camera", "com.google.android.GoogleCamera", "com.sec.android.app.camera"), "camera", "камера", "kamera")
        }

        @Volatile var instance: VoiceAgentAccessibilityService? = null
            private set
        val connected = MutableStateFlow(false)
    }

    @Volatile private var lastEventAt = 0L
    @Volatile var windowVersion = 0
        private set

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        connected.value = true
        com.voiceagent.app.voice.VoiceBus.log("A11Y", "accessibility service connected")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        lastEventAt = SystemClock.uptimeMillis()
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) windowVersion++
    }

    override fun onInterrupt() = Unit

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        connected.value = false
        com.voiceagent.app.voice.VoiceBus.log("ERR", "accessibility service disconnected — enable it again in Settings")
        return super.onUnbind(intent)
    }

    // ───────────────────────── observe ─────────────────────────

    fun snapshot(): UiSnapshot? {
        val root = rootInActiveWindow ?: return null
        return UiSnapshot.build(root, resources.displayMetrics)
    }

    /**
     * Optional vision input: a downscaled JPEG of the screen (Android 11+, needs canTakeScreenshot).
     * Returns null — never throws — when the system refuses (older Android, FLAG_SECURE window, rate limit);
     * the reason is written to [reasonOut] so the log box can show it. Android allows about one per second.
     */
    suspend fun screenshotJpeg(reasonOut: (String) -> Unit = {}): ByteArray? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) { reasonOut("needs Android 11+"); return null }
        return withContext(kotlinx.coroutines.Dispatchers.Main) {
            suspendCancellableCoroutine { cont ->
                takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
                    override fun onSuccess(result: ScreenshotResult) {
                        val out = try {
                            val buffer = result.hardwareBuffer
                            val hw = Bitmap.wrapHardwareBuffer(buffer, result.colorSpace ?: ColorSpace.get(ColorSpace.Named.SRGB))
                            if (hw == null) { buffer.close(); reasonOut("empty buffer"); null } else {
                                val soft = hw.copy(Bitmap.Config.ARGB_8888, false)
                                hw.recycle()
                                buffer.close() // only after the pixels were copied out
                                val maxSide = 1280f
                                val k = minOf(1f, maxSide / maxOf(soft.width, soft.height))
                                val scaled = if (k < 1f) Bitmap.createScaledBitmap(soft, (soft.width * k).toInt(), (soft.height * k).toInt(), true) else soft
                                val bos = ByteArrayOutputStream()
                                scaled.compress(Bitmap.CompressFormat.JPEG, 70, bos)
                                bos.toByteArray()
                            }
                        } catch (e: Exception) { reasonOut("encode failed: ${e.message}"); null }
                        if (cont.isActive) cont.resume(out)
                    }

                    override fun onFailure(errorCode: Int) {
                        reasonOut("takeScreenshot error code $errorCode")
                        if (cont.isActive) cont.resume(null)
                    }
                })
            }
        }
    }

    /** Waits until the UI has been quiet for [quietMs] (instead of fixed sleeps), capped by [timeoutMs]. */
    suspend fun awaitSettled(quietMs: Long = 120, timeoutMs: Long = 1500) {
        delay(60) // events trail the action by a few ms
        val start = SystemClock.uptimeMillis()
        while (true) {
            val now = SystemClock.uptimeMillis()
            if (now - lastEventAt >= quietMs || now - start >= timeoutMs) return
            delay(30)
        }
    }

    // ───────────────────────── act ─────────────────────────

    /**
     * @param speaker plays text through the loudspeaker (used by hold_and_speak).
     */
    suspend fun execute(a: AgentAction, snap: UiSnapshot, speaker: suspend (String) -> Unit): ActionResult =
        try {
            when (a.type) {
                ActionType.TAP -> tap(a, snap)
                ActionType.TYPE -> typeText(a, snap)
                ActionType.OPEN_APP -> openApp(a.app.orEmpty())
                ActionType.SCROLL -> scroll(a, snap)
                ActionType.BACK -> global(GLOBAL_ACTION_BACK, "back")
                ActionType.HOME -> global(GLOBAL_ACTION_HOME, "home")
                ActionType.WAIT -> { delay((a.durationMs ?: 500L).coerceIn(50L, 5000L)); ActionResult.ok("waited") }
                ActionType.COPY -> copy(a, snap)
                ActionType.PASTE -> paste(a, snap)
                ActionType.HOLD_AND_SPEAK -> holdAndSpeak(a, snap, speaker)
                else -> ActionResult.fail("unknown action '${a.type}'")
            }
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            ActionResult.fail(e.message ?: e.javaClass.simpleName)
        }

    private fun liveNode(id: Int?, snap: UiSnapshot): AccessibilityNodeInfo? {
        val n = snap.node(id) ?: return null
        return if (n.refresh()) n else null
    }

    private suspend fun tap(a: AgentAction, snap: UiSnapshot): ActionResult {
        val node = liveNode(a.node, snap) ?: return ActionResult.fail("node #${a.node} missing or stale")
        // Fast path: click the node or its nearest clickable ancestor.
        var n: AccessibilityNodeInfo? = node
        var hops = 0
        while (n != null && hops < 6) {
            if (n.isClickable && n.isEnabled && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                return ActionResult.ok("clicked")
            }
            n = n.parent
            hops++
        }
        // Fallback: synthetic tap at the centre of the node.
        val r = Rect().also { node.getBoundsInScreen(it) }
        return if (gestureTap(r.exactCenterX(), r.exactCenterY())) ActionResult.ok("tapped by gesture")
        else ActionResult.fail("tap failed")
    }

    private fun typeText(a: AgentAction, snap: UiSnapshot): ActionResult {
        val target = (if (a.node != null) liveNode(a.node, snap) else null)
            ?: findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            ?: return ActionResult.fail("no input field (give a node or focus one first)")
        target.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, a.text.orEmpty())
        }
        if (!target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) return ActionResult.fail("field rejected text")
        if (a.submit == true && Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            target.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
        }
        return ActionResult.ok("typed")
    }

    @Suppress("DEPRECATION")
    /**
     * open_app: (1) "settings" words → the system Settings screen, (2) well-known names → known package ids,
     * (3) any installed launcher app by package or label (exact, then partial) — all started through
     * PackageManager.getLaunchIntentForPackage().
     */
    private fun openApp(query: String): ActionResult {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return ActionResult.fail("open_app needs an app name")

        if (q in SETTINGS_WORDS) {
            return launch(Intent(android.provider.Settings.ACTION_SETTINGS), "Settings")
        }

        val pm = packageManager
        // known names first (also Russian / Uzbek spellings)
        KNOWN_APPS[q]?.forEach { pkg ->
            pm.getLaunchIntentForPackage(pkg)?.let { return launch(it, "$q ($pkg)") }
        }

        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0)
        fun label(ri: android.content.pm.ResolveInfo) = ri.loadLabel(pm).toString().lowercase()
        val match = apps.firstOrNull { it.activityInfo.packageName.equals(q, true) }
            ?: apps.firstOrNull { label(it) == q }
            ?: apps.firstOrNull { label(it).contains(q) }
            ?: apps.firstOrNull { q.contains(label(it)) && label(it).length >= 4 }
            ?: return ActionResult.fail(
                "app '$query' not found. Installed: " + apps.map { label(it) }.distinct().sorted().take(40).joinToString(", ")
            )
        val intent = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
            ?: return ActionResult.fail("no launch intent for ${match.activityInfo.packageName}")
        return launch(intent, label(match))
    }

    private fun launch(intent: Intent, what: String): ActionResult {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        return try {
            startActivity(intent)
            ActionResult.ok("opened $what")
        } catch (e: Exception) {
            // Background-activity-start restrictions differ per Android version / OEM: the model then uses home/back + the launcher UI.
            ActionResult.fail("could not launch $what: ${e.javaClass.simpleName}: ${e.message}")
        }
    }

    private suspend fun scroll(a: AgentAction, snap: UiSnapshot): ActionResult {
        val dir = a.direction ?: "down"
        val target = liveNode(a.node, snap) ?: liveNode(snap.firstScrollableId, snap)
        if (target != null) {
            var n: AccessibilityNodeInfo? = target
            while (n != null) {
                if (n.isScrollable) {
                    val action = when (dir) {
                        "up", "left" -> AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
                        else -> AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
                    }
                    if (n.performAction(action)) return ActionResult.ok("scrolled $dir")
                }
                n = n.parent
            }
        }
        // Fallback: swipe the middle of the screen. "down" reveals lower content => finger moves up.
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()
        val (x1, y1, x2, y2) = when (dir) {
            "up" -> listOf(w / 2, h * 0.30f, w / 2, h * 0.75f)
            "left" -> listOf(w * 0.25f, h / 2, w * 0.80f, h / 2)
            "right" -> listOf(w * 0.80f, h / 2, w * 0.25f, h / 2)
            else -> listOf(w / 2, h * 0.75f, w / 2, h * 0.30f)
        }
        val path = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        val ok = dispatch(GestureDescription.StrokeDescription(path, 0, 180))
        return if (ok) ActionResult.ok("swiped $dir") else ActionResult.fail("swipe failed")
    }

    private fun global(action: Int, name: String): ActionResult =
        if (performGlobalAction(action)) ActionResult.ok(name) else ActionResult.fail("$name failed")

    /**
     * Copies the node's REAL text (secrets are masked in the snapshot sent to the model, not here)
     * to the clipboard, flagged sensitive so Android hides it from clipboard previews.
     */
    private fun copy(a: AgentAction, snap: UiSnapshot): ActionResult {
        val node = liveNode(a.node, snap) ?: return ActionResult.fail("node #${a.node} missing or stale")
        val text = node.text?.toString()?.takeIf { it.isNotBlank() }
            ?: node.contentDescription?.toString()?.takeIf { it.isNotBlank() }
            ?: return ActionResult.fail("node has no text")
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("agent", text)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            clip.description.extras = PersistableBundle().apply { putBoolean(ClipDescription.EXTRA_IS_SENSITIVE, true) }
        }
        cm.setPrimaryClip(clip)
        return ActionResult.ok("copied ${text.length} chars")
    }

    private fun paste(a: AgentAction, snap: UiSnapshot): ActionResult {
        val target = (if (a.node != null) liveNode(a.node, snap) else null)
            ?: findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            ?: return ActionResult.fail("no input field to paste into")
        target.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        return if (target.performAction(AccessibilityNodeInfo.ACTION_PASTE)) ActionResult.ok("pasted")
        else ActionResult.fail("paste rejected")
    }

    /**
     * Press-and-hold a button (e.g. Telegram's microphone) while [speaker] plays the message through the
     * loudspeaker, then release. In Telegram, releasing sends the voice message — which is why the gate
     * ALWAYS asks before this action.
     */
    private suspend fun holdAndSpeak(a: AgentAction, snap: UiSnapshot, speaker: suspend (String) -> Unit): ActionResult {
        val node = liveNode(a.node, snap) ?: return ActionResult.fail("node #${a.node} missing or stale")
        val text = a.text?.takeIf { it.isNotBlank() } ?: return ActionResult.fail("hold_and_speak needs text")
        val r = Rect().also { node.getBoundsInScreen(it) }
        val path = Path().apply { moveTo(r.exactCenterX(), r.exactCenterY()) }

        // 1) Finger down and stay down (willContinue = true). ~700 ms so the app starts recording.
        val down = GestureDescription.StrokeDescription(path, 0, 700, true)
        if (!dispatch(down)) return ActionResult.fail("could not press and hold")
        try {
            speaker(text)
            delay(250) // tail so the last syllable is recorded
        } finally {
            // 2) Always lift the finger, even if the user said "stop" mid-sentence.
            withContext(NonCancellable) { dispatch(down.continueStroke(path, 0, 40, false)) }
        }
        return ActionResult.ok("held and spoke ${text.length} chars")
    }

    // ───────────────────────── gesture plumbing ─────────────────────────

    private suspend fun gestureTap(x: Float, y: Float): Boolean {
        val path = Path().apply { moveTo(x, y) }
        return dispatch(GestureDescription.StrokeDescription(path, 0, 50))
    }

    private suspend fun dispatch(stroke: GestureDescription.StrokeDescription): Boolean =
        suspendCancellableCoroutine { cont ->
            val gesture = GestureDescription.Builder().addStroke(stroke).build()
            val accepted = dispatchGesture(gesture, object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(g: GestureDescription?) { if (cont.isActive) cont.resume(true) }
                override fun onCancelled(g: GestureDescription?) { if (cont.isActive) cont.resume(false) }
            }, null)
            if (!accepted && cont.isActive) cont.resume(false)
        }
}
