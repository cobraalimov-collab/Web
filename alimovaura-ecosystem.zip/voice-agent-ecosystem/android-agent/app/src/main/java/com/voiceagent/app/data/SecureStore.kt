package com.voiceagent.app.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.security.SecureRandom
import kotlin.properties.ReadWriteProperty
import kotlin.reflect.KProperty

/** Encrypted key/value storage for secrets (API keys, licence key) and user settings. */
class SecureStore private constructor(ctx: Context) {

    private val prefs: SharedPreferences = EncryptedSharedPreferences.create(
        ctx,
        "voice_agent_secure",
        MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
    )

    private class Str(private val p: SharedPreferences, private val key: String, private val def: String) :
        ReadWriteProperty<Any?, String> {
        override fun getValue(thisRef: Any?, property: KProperty<*>): String = p.getString(key, def) ?: def
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: String) =
            p.edit().putString(key, value).apply()
    }

    private class Bool(private val p: SharedPreferences, private val key: String, private val def: Boolean) :
        ReadWriteProperty<Any?, Boolean> {
        override fun getValue(thisRef: Any?, property: KProperty<*>): Boolean = p.getBoolean(key, def)
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Boolean) =
            p.edit().putBoolean(key, value).apply()
    }

    private class Lng(private val p: SharedPreferences, private val key: String) :
        ReadWriteProperty<Any?, Long> {
        override fun getValue(thisRef: Any?, property: KProperty<*>): Long = p.getLong(key, 0L)
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Long) =
            p.edit().putLong(key, value).apply()
    }

    // --- brain ---
    /** Anthropic API key (`sk-ant-api03-…`), sent as the `x-api-key` header. Only used when BuildConfig.BRAIN_BASE_URL is empty. */
    var anthropicKey by Str(prefs, "anthropic_key", "")
    /** Claude vision model. Editable on the main screen. */
    var anthropicModel by Str(prefs, "anthropic_model", DEFAULT_ANTHROPIC_MODEL)
    /** Opt-in: also send a screenshot (vision). Off by default — a screenshot can show secrets the UI tree masks. */
    var sendScreenshot by Bool(prefs, "send_screenshot", false)

    // --- voice ---
    /** "uz" | "ru" | "en" */
    var language by Str(prefs, "language", "uz")
    /** Comma-separated wake words, lower-case. */
    var wakeWords by Str(prefs, "wake_words", "agent,hey agent,агент,yordamchi")
    var elevenKey by Str(prefs, "eleven_key", "")
    var elevenVoiceId by Str(prefs, "eleven_voice", "")
    /** Check which model/voice supports Uzbek in your ElevenLabs account. */
    var elevenModel by Str(prefs, "eleven_model", "eleven_multilingual_v2")

    // --- licence ---
    var licenseKey by Str(prefs, "license_key", "")
    var licenseVerifiedAt by Lng(prefs, "license_verified_at")

    /** Short code the user types on the website; the wallet signs it so the key is bound to this install. */
    val deviceCode: String
        get() {
            val existing = prefs.getString("device_code", null)
            if (existing != null) return existing
            val alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789" // no 0/O/1/I
            val rnd = SecureRandom()
            val raw = CharArray(12) { alphabet[rnd.nextInt(alphabet.length)] }
            val code = String(raw).chunked(4).joinToString("-")
            prefs.edit().putString("device_code", code).apply()
            return code
        }

    companion object {
        const val DEFAULT_ANTHROPIC_MODEL = "claude-sonnet-4-5-20250929"
        @Volatile private var instance: SecureStore? = null
        fun get(ctx: Context): SecureStore =
            instance ?: synchronized(this) {
                instance ?: SecureStore(ctx.applicationContext).also { instance = it }
            }
    }
}
