package com.voiceagent.app.voice

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import com.voiceagent.app.agent.L10n
import com.voiceagent.app.data.SecureStore
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonObject
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File
import java.io.IOException
import java.util.UUID
import java.util.concurrent.TimeUnit

/**
 * Text-to-speech.
 *  1. ElevenLabs (natural voice) when an API key + voice id are configured and the call succeeds.
 *  2. Otherwise Android TTS (Google engine, uz-UZ) with a male voice if the engine offers one.
 *
 * While speaking, [VoiceBus.speaking] is true so the listener releases the microphone.
 */
class SpeechOutput(private val ctx: Context, private val store: SecureStore) {

    private val http = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    private val ttsReady = CompletableDeferred<Boolean>()
    private val tts: TextToSpeech = TextToSpeech(ctx.applicationContext) { status ->
        ttsReady.complete(status == TextToSpeech.SUCCESS)
    }

    suspend fun speak(text: String) {
        if (text.isBlank()) return
        VoiceBus.speaking.value = true
        try {
            val key = store.elevenKey
            val voice = store.elevenVoiceId
            if (key.isNotBlank() && voice.isNotBlank()) {
                val file = downloadElevenLabs(text, key, voice)
                if (file != null) {
                    try { playFile(file) } finally { file.delete() }
                    return
                }
            }
            speakWithAndroid(text)
        } finally {
            VoiceBus.speaking.value = false
        }
    }

    fun shutdown() {
        tts.stop()
        tts.shutdown()
    }

    // ───────────── Android TTS ─────────────

    private suspend fun speakWithAndroid(text: String) {
        if (!ttsReady.await()) {
            VoiceBus.log("ERR", "TTS: Android text-to-speech engine failed to start")
            return
        }
        val locale = chooseLocale(L10n.locale(store.language))
        pickMaleVoice(locale)?.let { tts.voice = it }

        val id = UUID.randomUUID().toString()
        val done = CompletableDeferred<Unit>()
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) = Unit
            override fun onDone(utteranceId: String?) { if (utteranceId == id) done.complete(Unit) }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { if (utteranceId == id) done.complete(Unit) }
        })
        if (tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, id) != TextToSpeech.SUCCESS) {
            VoiceBus.log("ERR", "TTS: speak() was refused by the engine")
            return
        }
        try {
            // Never wait forever: a stuck engine would keep the microphone released for good.
            if (withTimeoutOrNull(30_000) { done.await() } == null) {
                VoiceBus.log("ERR", "TTS: no completion callback after 30 s — continuing")
                tts.stop()
            }
        } catch (e: CancellationException) {
            tts.stop()
            throw e
        }
    }

    private var lastLocaleNote = ""

    /**
     * Uzbek → Russian fallback: most phones have no uz-UZ voice, so if the engine has no data for it
     * the Uzbek Latin text is read by the ru-RU voice (understandable, with a Russian accent).
     */
    private fun chooseLocale(wanted: java.util.Locale): java.util.Locale {
        fun ok(l: java.util.Locale): Boolean {
            val r = tts.setLanguage(l)
            return r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
        }
        val chosen = when {
            ok(wanted) -> wanted
            wanted.language == "uz" && ok(L10n.locale("ru")) -> L10n.locale("ru")
            ok(java.util.Locale.US) -> java.util.Locale.US
            else -> wanted
        }
        val note = "TTS voice: ${chosen.toLanguageTag()}" + if (chosen != wanted) " (${wanted.toLanguageTag()} voice not installed on this phone)" else ""
        if (note != lastLocaleNote) { lastLocaleNote = note; VoiceBus.log(if (chosen == wanted) "TTS" else "ERR", note) }
        return chosen
    }

    /** Engines don't expose gender officially; Google voices usually carry "male"/"female" hints. Best effort. */
    private fun pickMaleVoice(locale: java.util.Locale): Voice? = try {
        tts.voices.orEmpty()
            .filter { it.locale.language == locale.language }
            .firstOrNull { v ->
                val n = v.name.lowercase()
                (n.contains("male") && !n.contains("female")) || n.contains("-x-uzm") || n.contains("-x-rum")
            }
    } catch (e: Exception) {
        null
    }

    // ───────────── ElevenLabs ─────────────

    private suspend fun downloadElevenLabs(text: String, key: String, voiceId: String): File? =
        withContext(Dispatchers.IO) {
            try {
                val body = buildJsonObject {
                    put("text", text)
                    put("model_id", store.elevenModel)
                    putJsonObject("voice_settings") { put("stability", 0.5); put("similarity_boost", 0.8) }
                }.toString().toRequestBody("application/json".toMediaType())
                val req = Request.Builder()
                    .url("https://api.elevenlabs.io/v1/text-to-speech/$voiceId?output_format=mp3_44100_128")
                    .header("xi-api-key", key)
                    .post(body)
                    .build()
                http.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) return@withContext null
                    val bytes = resp.body?.bytes() ?: return@withContext null
                    File.createTempFile("tts", ".mp3", ctx.cacheDir).apply { writeBytes(bytes) }
                }
            } catch (e: IOException) {
                null // fall back to Android TTS
            }
        }

    private suspend fun playFile(file: File) = withContext(Dispatchers.Main) {
        val done = CompletableDeferred<Unit>()
        val player = MediaPlayer().apply {
            setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            setDataSource(file.absolutePath)
            setOnCompletionListener { done.complete(Unit) }
            setOnErrorListener { _, _, _ -> done.complete(Unit); true }
            prepare()
        }
        try {
            player.start()
            done.await()
        } finally {
            player.release()
        }
    }
}
