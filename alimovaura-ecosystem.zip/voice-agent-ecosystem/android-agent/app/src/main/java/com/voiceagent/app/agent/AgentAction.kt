package com.voiceagent.app.agent

import kotlinx.serialization.Serializable

object ActionType {
    const val TAP = "tap"
    const val TYPE = "type"
    const val OPEN_APP = "open_app"
    const val SCROLL = "scroll"
    const val BACK = "back"
    const val HOME = "home"
    const val WAIT = "wait"
    const val COPY = "copy"
    const val PASTE = "paste"
    const val HOLD_AND_SPEAK = "hold_and_speak"

    val ALL = setOf(TAP, TYPE, OPEN_APP, SCROLL, BACK, HOME, WAIT, COPY, PASTE, HOLD_AND_SPEAK)
}

/** One low-level phone action, as returned by Claude. */
@Serializable
data class AgentAction(
    val type: String,
    /** Node id (#N) from the UI snapshot the model was shown. */
    val node: Int? = null,
    /** Text to type / to speak (hold_and_speak). */
    val text: String? = null,
    /** App name or package for open_app. */
    val app: String? = null,
    /** scroll: up | down | left | right — which way to reveal more content. */
    val direction: String? = null,
    val durationMs: Long? = null,
    /** type: press the keyboard "enter/send" action afterwards. */
    val submit: Boolean? = null,
    /** Model's own opinion that the step is sensitive. The code gate never relies on it alone. */
    val sensitive: Boolean? = null,
)

/** The model's reply for one observation. */
@Serializable
data class BrainDecision(
    val actions: List<AgentAction> = emptyList(),
    /** Short message to say aloud (final result, or a question). */
    val say: String? = null,
    /** Plain-language description of the sensitive step, in the user's language. */
    val confirmationPrompt: String? = null,
    val done: Boolean = false,
)

data class ActionResult(val ok: Boolean, val detail: String) {
    companion object {
        fun ok(detail: String = "ok") = ActionResult(true, detail)
        fun fail(detail: String) = ActionResult(false, detail)
    }
}
