package com.voiceagent.app.license

import com.voiceagent.app.BuildConfig
import com.voiceagent.app.data.SecureStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonObject
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.web3j.crypto.Hash
import org.web3j.crypto.Keys
import org.web3j.crypto.Sign
import org.web3j.utils.Numeric
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Wallet-signature licence check.
 *
 * Licence key (created on the website after purchase):   VA1.<chainId>.<wallet>.<productId>.<signature>
 * The wallet signed (EIP-191 personal_sign):
 *     VoiceAgent License v1\nProduct: <id>\nDevice: <XXXX-XXXX-XXXX>\nChain: <chainId>\nContract: <lower-case address>
 *
 * Verification (all on the phone):
 *   1. Re-build the message with THIS device's code → a key made for another phone fails.
 *   2. ecrecover the signer; it must equal the wallet in the key.
 *   3. eth_call Marketplace.hasAccess(wallet, productId) on the chain → must be true (purchase exists, not revoked).
 *
 * Result is cached for 24 h; if the RPC is unreachable a previously verified licence keeps working for 72 h.
 *
 * NOTE: client-side checks can be patched out of an APK. The real enforcement point is the brain proxy
 * (BRAIN_BASE_URL), which must run the same check server-side before forwarding to Claude — see README.
 */
class LicenseManager(private val store: SecureStore) {

    sealed interface Result {
        data object Valid : Result
        data object Offline : Result
        data class Invalid(val reason: String) : Result
    }

    private data class Chain(val id: Long, val rpc: String, val contract: String)

    private val zero = "0x0000000000000000000000000000000000000000"
    private val chains = listOf(
        Chain(137, BuildConfig.POLYGON_RPC, BuildConfig.POLYGON_CONTRACT),
        Chain(56, BuildConfig.BNB_RPC, BuildConfig.BNB_CONTRACT),
    ).filter { !it.contract.equals(zero, ignoreCase = true) }

    private val http = OkHttpClient.Builder()
        .connectTimeout(6, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    /** Cheap check used before every task. */
    suspend fun isValid(): Boolean {
        val key = store.licenseKey
        if (key.isBlank()) return false
        val now = System.currentTimeMillis()
        val age = now - store.licenseVerifiedAt
        if (store.licenseVerifiedAt > 0 && age < RECHECK_MS) return true
        return when (verify(key)) {
            Result.Valid -> { store.licenseVerifiedAt = now; true }
            Result.Offline -> store.licenseVerifiedAt > 0 && age < GRACE_MS
            is Result.Invalid -> { store.licenseVerifiedAt = 0; false }
        }
    }

    suspend fun verify(rawKey: String): Result = withContext(Dispatchers.IO) {
        val parts = rawKey.trim().split(".")
        if (parts.size != 5 || parts[0] != "VA1") return@withContext Result.Invalid("Key format is wrong")
        val chainId = parts[1].toLongOrNull()
        val claimed = parts[2]
        val productId = parts[3].toLongOrNull()
        val signature = parts[4]

        val chain = chains.firstOrNull { it.id == chainId }
            ?: return@withContext Result.Invalid("This build is not configured for chain $chainId")
        if (productId == null || productId != BuildConfig.PRODUCT_ID) return@withContext Result.Invalid("Wrong product")

        val signer = try {
            recoverSigner(message(productId, store.deviceCode, chain), signature)
        } catch (e: Exception) {
            return@withContext Result.Invalid("Signature is not valid")
        }
        if (!signer.equals(claimed, ignoreCase = true)) {
            return@withContext Result.Invalid("Key was created for a different device or wallet")
        }

        try {
            if (hasAccess(chain, signer, productId)) Result.Valid
            else Result.Invalid("This wallet has not purchased access on-chain")
        } catch (e: IOException) {
            Result.Offline
        }
    }

    private fun message(productId: Long, device: String, chain: Chain): String =
        "VoiceAgent License v1\nProduct: $productId\nDevice: $device\nChain: ${chain.id}\nContract: ${chain.contract.lowercase()}"

    /** ecrecover for an EIP-191 "personal_sign" signature (65 bytes r‖s‖v). */
    private fun recoverSigner(message: String, signatureHex: String): String {
        val sig = Numeric.hexStringToByteArray(signatureHex)
        require(sig.size == 65) { "bad signature length" }
        var v = sig[64].toInt() and 0xff
        if (v < 27) v += 27
        val data = Sign.SignatureData(v.toByte(), sig.copyOfRange(0, 32), sig.copyOfRange(32, 64))
        val pub = Sign.signedPrefixedMessageToKey(message.toByteArray(Charsets.UTF_8), data)
        return "0x" + Keys.getAddress(pub)
    }

    /** eth_call Marketplace.hasAccess(address,uint256) → bool, with hand-encoded ABI (no web3j RPC stack needed). */
    private fun hasAccess(chain: Chain, wallet: String, productId: Long): Boolean {
        val selector = Hash.sha3String("hasAccess(address,uint256)").substring(0, 10) // 0x + 4 bytes
        val data = selector +
            wallet.removePrefix("0x").lowercase().padStart(64, '0') +
            productId.toString(16).padStart(64, '0')

        val payload = buildJsonObject {
            put("jsonrpc", "2.0")
            put("id", 1)
            put("method", "eth_call")
            put("params", buildJsonArray {
                add(buildJsonObject { put("to", chain.contract); put("data", data) })
                add(kotlinx.serialization.json.JsonPrimitive("latest"))
            })
        }.toString()

        val req = Request.Builder().url(chain.rpc)
            .post(payload.toRequestBody("application/json".toMediaType()))
            .build()
        http.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) throw IOException("RPC HTTP ${resp.code}")
            val root = Json.parseToJsonElement(resp.body?.string().orEmpty()).jsonObject
            if (root["error"] != null) throw IOException("RPC error")
            val result = root["result"]?.jsonPrimitive?.contentOrNull ?: throw IOException("RPC empty")
            return result.removePrefix("0x").trimStart('0') == "1"
        }
    }

    private companion object {
        const val RECHECK_MS = 24L * 60 * 60 * 1000
        const val GRACE_MS = 72L * 60 * 60 * 1000
    }
}
