package com.voiceagent.app.accessibility

import android.graphics.Rect
import android.util.DisplayMetrics
import android.util.SparseArray
import android.view.accessibility.AccessibilityNodeInfo

/**
 * A compact, token-cheap text rendering of the current screen plus live node references.
 *
 * One line per meaningful element:
 *   #12 Button "Send" desc="Send" id=send_btn [click] @980,2100
 *
 * Privacy: password fields are replaced by ••••, and long key-like tokens are masked as ‹secret len=N›
 * so they never leave the phone. The agent can still copy them (the copy action reads the real node text locally).
 */
class UiSnapshot private constructor(
    val packageName: String,
    val text: String,
    private val nodes: SparseArray<AccessibilityNodeInfo>,
    private val labels: SparseArray<String>,
    val firstScrollableId: Int?,
) {
    fun node(id: Int?): AccessibilityNodeInfo? = if (id == null) null else nodes.get(id)

    /** Lower-cased "text desc resourceId" of a node — used by the permission gate. Empty if unknown. */
    fun label(id: Int?): String = if (id == null) "" else labels.get(id).orEmpty()

    companion object {
        private const val MAX_NODES = 220
        private const val MAX_DEPTH = 45
        private val SECRET = Regex("[A-Za-z0-9_\\-]{24,}")

        fun build(root: AccessibilityNodeInfo, dm: DisplayMetrics): UiSnapshot {
            val nodes = SparseArray<AccessibilityNodeInfo>()
            val labels = SparseArray<String>()
            val sb = StringBuilder()
            var next = 1
            var scrollable: Int? = null
            val pkg = root.packageName?.toString().orEmpty()
            sb.append("package=").append(pkg)
                .append(" screen=").append(dm.widthPixels).append('x').append(dm.heightPixels).append('\n')

            fun visit(n: AccessibilityNodeInfo, depth: Int) {
                if (next > MAX_NODES || depth > MAX_DEPTH || !n.isVisibleToUser) return

                val rawText = n.text?.toString().orEmpty()
                val desc = n.contentDescription?.toString().orEmpty()
                val hint = n.hintText?.toString().orEmpty()
                val interactive = n.isClickable || n.isLongClickable || n.isEditable || n.isScrollable || n.isCheckable

                if (rawText.isNotBlank() || desc.isNotBlank() || hint.isNotBlank() || interactive) {
                    val id = next++
                    nodes.put(id, n)

                    val resId = n.viewIdResourceName?.substringAfter(":id/").orEmpty()
                    labels.put(id, "$rawText $desc $resId".lowercase())
                    if (scrollable == null && n.isScrollable) scrollable = id

                    var shown = when {
                        n.isPassword -> "••••"
                        else -> redact(rawText)
                    }
                    // Clickable containers (list rows) often carry no text of their own: borrow from children.
                    if (shown.isBlank() && desc.isBlank() && n.isClickable) shown = "~" + childText(n)

                    val cls = (n.className?.toString() ?: "View").substringAfterLast('.')
                    val flags = buildList {
                        if (n.isClickable) add("click")
                        if (n.isLongClickable) add("long")
                        if (n.isEditable) add("edit")
                        if (n.isScrollable) add("scroll")
                        if (n.isChecked) add("checked")
                        if (n.isFocused) add("focused")
                        if (!n.isEnabled) add("disabled")
                    }
                    val r = Rect().also { n.getBoundsInScreen(it) }

                    sb.append('#').append(id).append(' ').append(cls)
                    if (shown.isNotBlank()) sb.append(" \"").append(shown.take(200).replace('\n', ' ')).append('"')
                    if (desc.isNotBlank()) sb.append(" desc=\"").append(redact(desc).take(80)).append('"')
                    if (hint.isNotBlank() && rawText.isBlank()) sb.append(" hint=\"").append(hint.take(60)).append('"')
                    if (resId.isNotBlank()) sb.append(" id=").append(resId)
                    if (flags.isNotEmpty()) sb.append(" [").append(flags.joinToString(",")).append(']')
                    sb.append(" @").append(r.centerX()).append(',').append(r.centerY()).append('\n')
                }
                for (i in 0 until n.childCount) {
                    n.getChild(i)?.let { visit(it, depth + 1) }
                }
            }
            visit(root, 0)
            return UiSnapshot(pkg, sb.toString(), nodes, labels, scrollable)
        }

        private fun redact(s: String): String =
            if (s.length < 24) s else SECRET.replace(s) { m ->
                val v = m.value
                if (v.any { it.isDigit() } && v.any { it.isLetter() }) "‹secret len=${v.length}›" else v
            }

        private fun childText(n: AccessibilityNodeInfo): String {
            val parts = ArrayList<String>(3)
            fun walk(x: AccessibilityNodeInfo, depth: Int) {
                if (parts.size >= 3 || depth > 4) return
                val t = x.text?.toString()?.takeIf { it.isNotBlank() } ?: x.contentDescription?.toString()?.takeIf { it.isNotBlank() }
                if (t != null && !x.isPassword) parts.add(redact(t).take(50))
                for (i in 0 until x.childCount) x.getChild(i)?.let { walk(it, depth + 1) }
            }
            walk(n, 0)
            return parts.joinToString(" | ")
        }
    }
}
