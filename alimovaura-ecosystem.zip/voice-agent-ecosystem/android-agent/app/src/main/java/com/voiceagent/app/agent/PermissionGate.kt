package com.voiceagent.app.agent

import com.voiceagent.app.voice.SpeechOutput
import com.voiceagent.app.voice.VoiceBus
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

/**
 * Human-in-the-loop gate.
 *
 * The decision "is this sensitive?" is made HERE, in code, from the real node label — it never depends
 * only on what the model claims, so a confused or prompt-injected model cannot skip the question.
 * Sensitive actions: anything that sends / posts / pays / deletes, press-and-hold voice messages,
 * clipboard copies (keys), and keyboard "send" submits.
 */
class PermissionGate(private val speech: SpeechOutput) {

    private val sensitiveWords = listOf(
        // English
        "send", "submit", "post", "publish", "reply", "forward", "pay", "buy", "purchase", "confirm", "delete", "remove", "transfer",
        // Uzbek (Latin)
        "jo'nat", "jo‘nat", "yubor", "to'la", "to‘la", "o'chir", "o‘chir", "sotib",
        // Russian
        "отправ", "послать", "ответить", "переслать", "оплат", "купить", "удал", "опубликов", "перевест",
    )

    fun requiresConfirmation(action: AgentAction, nodeLabel: String): Boolean {
        if (action.sensitive == true) return true
        return when (action.type) {
            ActionType.HOLD_AND_SPEAK, ActionType.COPY -> true
            ActionType.TYPE -> action.submit == true
            ActionType.TAP -> sensitiveWords.any { nodeLabel.contains(it) }
            else -> false
        }
    }

    /**
     * Speaks "<what will happen>. Should I execute this now?" and waits up to [timeoutMs] for a spoken or
     * tapped answer. Silence, noise or anything unclear counts as NO.
     */
    suspend fun confirm(whatWillHappen: String?, technicalDetail: String, lang: String, timeoutMs: Long = 20_000): Boolean =
        coroutineScope {
            val what = whatWillHappen?.trim()?.trimEnd('.')?.takeIf { it.isNotEmpty() }?.let { "$it." }
            val spoken = listOfNotNull(what, L10n.t(lang, "confirm")).joinToString(" ")
            val answer = CompletableDeferred<Boolean>()
            VoiceBus.confirmation.value = VoiceBus.Confirmation(spoken, technicalDetail, answer)

            val voice = launch {
                VoiceBus.transcripts.collect { heard ->
                    L10n.parseYesNo(heard)?.let { answer.complete(it) }
                }
            }
            try {
                speech.speak(spoken) // microphone is released while speaking, so we can't hear ourselves
                withTimeoutOrNull(timeoutMs) { answer.await() } ?: false
            } finally {
                voice.cancel()
                VoiceBus.confirmation.value = null
            }
        }
}
