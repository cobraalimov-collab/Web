package com.voiceagent.app.voice

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.voiceagent.app.MainActivity
import com.voiceagent.app.agent.AgentOrchestrator
import com.voiceagent.app.agent.L10n
import com.voiceagent.app.data.SecureStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch

/**
 * Always-on microphone: a foreground service (type "microphone") that runs Android's SpeechRecognizer in a
 * restart loop, filters utterances by wake word, and hands commands to the [AgentOrchestrator].
 *
 * Android limits: a microphone foreground service must be STARTED while the app is visible (Android 14+),
 * and some OEMs kill it unless battery optimisation is disabled for the app — see README.
 * For a true offline wake word swap [handleUtterance]'s text matching for Porcupine / openWakeWord.
 */
class VoiceListenerService : Service() {

    companion object {
        val running = MutableStateFlow(false)
        private const val CHANNEL_ID = "voice_agent_listening"
        private const val NOTIF_ID = 42
        private const val ACTIVE_WINDOW_MS = 8_000L
        private const val WATCHDOG_MS = 15_000L
        // SpeechRecognizer error codes added in newer Android versions (plain ints work on every version).
        private const val ERROR_TOO_MANY_REQUESTS = 10
        private const val ERROR_LANGUAGE_NOT_SUPPORTED = 12
        private const val ERROR_LANGUAGE_UNAVAILABLE = 13

        /** Call while the app is visible. Refuses to start without the microphone permission (Android 14 would crash). */
        fun start(ctx: Context) {
            if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
            ContextCompat.startForegroundService(ctx, Intent(ctx, VoiceListenerService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, VoiceListenerService::class.java))
        }
    }

    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private lateinit var store: SecureStore
    private lateinit var agent: AgentOrchestrator

    private var recognizer: SpeechRecognizer? = null
    private var activeUntil = 0L
    private val restart = Runnable { startRecognizer() }

    /** Set when the device has no Uzbek recogniser: Uzbek speech is then recognised as Russian (ru-RU). */
    private var uzbekFallbackToRussian = false
    private var consecutiveErrors = 0

    /** If the recogniser neither answers nor errors within this time, it is silently dead: rebuild it. */
    private val watchdog = Runnable {
        VoiceBus.log("ERR", "speech recognizer gave no callback for ${WATCHDOG_MS / 1000} s — restarting it")
        startRecognizer()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            stopSelf()
            return
        }
        store = SecureStore.get(this)
        createChannel()
        ServiceCompat.startForeground(this, NOTIF_ID, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)

        agent = AgentOrchestrator(applicationContext, scope)
        scope.launch(Dispatchers.Default) { agent.run() }

        // One driver for the mic: released while we speak, re-acquired right after.
        scope.launch {
            VoiceBus.speaking.collect { speaking ->
                if (speaking) stopRecognizer() else scheduleRestart(250)
            }
        }
        running.value = true
        VoiceBus.log("MIC", "listening service started (language ${store.language})")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        running.value = false
        main.removeCallbacks(restart)
        main.removeCallbacks(watchdog)
        stopRecognizer()
        if (::agent.isInitialized) agent.shutdown()
        scope.cancel()
        super.onDestroy()
    }

    // ───────────────────────── recogniser loop ─────────────────────────

    private fun scheduleRestart(delayMs: Long) {
        main.removeCallbacks(restart)
        main.postDelayed(restart, delayMs)
    }

    private fun recognitionTag(): String =
        if (store.language == "uz" && uzbekFallbackToRussian) L10n.tag("ru") else L10n.tag(store.language)

    private fun startRecognizer() {
        if (VoiceBus.speaking.value) return
        stopRecognizer()
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            VoiceBus.status.value = "Speech recognition not available — install Google Speech Services"
            VoiceBus.log("ERR", "SpeechRecognizer.isRecognitionAvailable() = false — install/enable Google Speech Services")
            return
        }
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = r
        r.setRecognitionListener(listener)
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            val tag = recognitionTag()
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, tag)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, tag)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            // allow short pauses inside one command
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1200L)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        }
        r.startListening(intent)
        VoiceBus.listening.value = true
        main.removeCallbacks(watchdog)
        main.postDelayed(watchdog, WATCHDOG_MS)
    }

    private fun stopRecognizer() {
        main.removeCallbacks(watchdog)
        recognizer?.run { cancel(); destroy() }
        recognizer = null
        VoiceBus.listening.value = false
    }

    private val listener = object : RecognitionListener {
        override fun onResults(results: Bundle?) {
            main.removeCallbacks(watchdog)
            consecutiveErrors = 0
            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
            if (text.isNotBlank()) {
                VoiceBus.log("MIC", "heard: “${text.trim()}”")
                handleUtterance(text.trim())
            }
            scheduleRestart(150)
        }

        override fun onError(error: Int) {
            main.removeCallbacks(watchdog)
            when (error) {
                // Silence / nothing understood: normal while idle. Just listen again, no log spam, no backoff.
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> {
                    consecutiveErrors = 0
                    scheduleRestart(150)
                    return
                }
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                    VoiceBus.log("ERR", "speech recognizer: ${speechError(error)}")
                    stopSelf()
                    return
                }
                // Uzbek recogniser not installed / not downloaded: fall back to Russian instead of failing forever.
                ERROR_LANGUAGE_NOT_SUPPORTED, ERROR_LANGUAGE_UNAVAILABLE -> {
                    if (store.language == "uz" && !uzbekFallbackToRussian) {
                        uzbekFallbackToRussian = true
                        VoiceBus.log("ERR", "speech recognizer: ${speechError(error)} — Uzbek recognition is not available on this phone, switching to ru-RU")
                        scheduleRestart(200)
                        return
                    }
                }
            }
            VoiceBus.log("ERR", "speech recognizer: ${speechError(error)}")
            consecutiveErrors++
            // Back off a little on repeated real errors, but never give up.
            val wait = when (error) {
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY, SpeechRecognizer.ERROR_CLIENT -> 1000L
                SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT, SpeechRecognizer.ERROR_SERVER -> 1500L
                ERROR_TOO_MANY_REQUESTS -> 3000L
                else -> 500L
            }
            scheduleRestart(minOf(wait * minOf(consecutiveErrors, 4), 8000L))
        }

        override fun onReadyForSpeech(params: Bundle?) = Unit
        override fun onBeginningOfSpeech() = Unit
        override fun onRmsChanged(rmsdB: Float) = Unit
        override fun onBufferReceived(buffer: ByteArray?) = Unit
        override fun onEndOfSpeech() = Unit
        override fun onPartialResults(partialResults: Bundle?) = Unit
        override fun onEvent(eventType: Int, params: Bundle?) = Unit
    }

    private fun speechError(code: Int) = when (code) {
        SpeechRecognizer.ERROR_AUDIO -> "ERROR_AUDIO (3)"
        SpeechRecognizer.ERROR_CLIENT -> "ERROR_CLIENT (5)"
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "ERROR_INSUFFICIENT_PERMISSIONS (9) — allow the microphone"
        SpeechRecognizer.ERROR_NETWORK -> "ERROR_NETWORK (2) — Google speech needs internet for this language"
        SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "ERROR_NETWORK_TIMEOUT (1)"
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "ERROR_RECOGNIZER_BUSY (8)"
        SpeechRecognizer.ERROR_SERVER -> "ERROR_SERVER (4)"
        ERROR_LANGUAGE_NOT_SUPPORTED -> "ERROR_LANGUAGE_NOT_SUPPORTED (12)"
        ERROR_LANGUAGE_UNAVAILABLE -> "ERROR_LANGUAGE_UNAVAILABLE (13)"
        ERROR_TOO_MANY_REQUESTS -> "ERROR_TOO_MANY_REQUESTS (10)"
        SpeechRecognizer.ERROR_NO_MATCH -> "ERROR_NO_MATCH (7)"
        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "ERROR_SPEECH_TIMEOUT (6)"
        else -> "error code $code"
    }

    // ───────────────────────── wake word ─────────────────────────

    private fun handleUtterance(text: String) {
        VoiceBus.transcripts.tryEmit(text) // yes/no answers listen here
        if (VoiceBus.confirmation.value != null) return // a confirmation is pending: not a new command

        if (L10n.isStop(text)) { VoiceBus.commands.tryEmit(text); return }

        val now = SystemClock.elapsedRealtime()
        val stripped = stripWakeWord(text)
        when {
            stripped != null && stripped.isNotBlank() -> { VoiceBus.log("MIC", "command: “$stripped”"); VoiceBus.commands.tryEmit(stripped) }
            stripped != null -> { // wake word alone → open a short window for the actual command
                VoiceBus.log("MIC", "wake word heard — waiting for the command")
                activeUntil = now + ACTIVE_WINDOW_MS
                scope.launch { agent.speech.speak(L10n.t(store.language, "listening")) }
            }
            now < activeUntil -> { activeUntil = 0; VoiceBus.log("MIC", "command: “$text”"); VoiceBus.commands.tryEmit(text) }
            else -> VoiceBus.log("MIC", "ignored (no wake word): “$text”")
        }
    }

    /** Returns the text after the wake word, "" if only the wake word was said, or null if there was none. */
    private fun stripWakeWord(text: String): String? {
        val lower = text.lowercase()
        val words = store.wakeWords.split(',').map { it.trim().lowercase() }.filter { it.isNotEmpty() }
            .sortedByDescending { it.length } // "hey agent" before "agent"
        for (w in words) {
            if (lower == w) return ""
            if (lower.startsWith("$w ") || lower.startsWith("$w,")) {
                return text.substring(w.length).trimStart(' ', ',', '.', '!', ':')
            }
        }
        return null
    }

    // ───────────────────────── notification ─────────────────────────

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Voice Agent listening", NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Voice Agent is listening")
            .setContentText("Say the wake word, then your command")
            .setOngoing(true)
            .setContentIntent(open)
            .build()
    }
}
