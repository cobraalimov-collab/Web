package com.voiceagent.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.voiceagent.app.accessibility.VoiceAgentAccessibilityService
import com.voiceagent.app.agent.BrainConfig
import com.voiceagent.app.agent.ClaudeBrainManager
import com.voiceagent.app.data.SecureStore
import com.voiceagent.app.license.LicenseManager
import com.voiceagent.app.voice.VoiceBus
import com.voiceagent.app.voice.VoiceListenerService
import kotlinx.coroutines.launch

private val Gold = Color(0xFFD4AF37)
private val GoldDeep = Color(0xFF8A6D0B)
private val Ink = Color(0xFF2B2616)

/**
 * Entry point. Flow:  licence gate → permission checklist → start/stop the always-on listener.
 * Everything heavy lives in [VoiceListenerService] (mic + agent loop) and
 * [VoiceAgentAccessibilityService] (screen reading + actions); this screen only configures and monitors.
 */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = Gold, onPrimary = Ink,
                    background = Color.White, surface = Color.White,
                    onSurface = Ink, onBackground = Ink,
                )
            ) { AgentApp() }
        }
    }
}

@Composable
private fun AgentApp() {
    val ctx = LocalContext.current
    val store = remember { SecureStore.get(ctx) }
    val license = remember { LicenseManager(store) }
    var licensed by remember { mutableStateOf<Boolean?>(null) }

    // Licence gate on every launch: wallet signature + on-chain purchase check (cached, with offline grace).
    LaunchedEffect(Unit) { licensed = license.isValid() }

    Surface(Modifier.fillMaxSize(), color = Color.White) {
        Column(
            Modifier.fillMaxSize().systemBarsPadding().verticalScroll(rememberScrollState()).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Text("VOICE AGENT", style = MaterialTheme.typography.headlineMedium, color = Gold)
            when (licensed) {
                null -> CircularProgressIndicator(color = Gold)
                false -> LicenseScreen(store, license) { licensed = true }
                true -> ControlScreen(store)
            }
            LogBox()
        }
    }
    ConfirmationDialog()
}

// ───────────────────────── licence ─────────────────────────

@Composable
private fun LicenseScreen(store: SecureStore, license: LicenseManager, onValid: () -> Unit) {
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    var key by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }

    Text("Activate your licence", style = MaterialTheme.typography.titleLarge)
    Text("1. On the marketplace website, buy access with your wallet.\n" +
        "2. In “Activate your phone”, paste this device code and sign with your wallet.\n" +
        "3. Paste the licence key you get below.")

    OutlinedCard(Modifier.fillMaxWidth()) {
        Row(Modifier.padding(16.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(store.deviceCode, style = MaterialTheme.typography.headlineSmall, fontFamily = FontFamily.Monospace, color = GoldDeep)
            TextButton(onClick = { clipboard.setText(AnnotatedString(store.deviceCode)) }) { Text("Copy", color = GoldDeep) }
        }
    }

    OutlinedTextField(
        value = key, onValueChange = { key = it },
        label = { Text("Licence key (VA1.…)") },
        minLines = 3, modifier = Modifier.fillMaxWidth(),
    )
    Button(
        enabled = key.isNotBlank() && !busy,
        onClick = {
            busy = true
            message = null
            scope.launch {
                when (val r = license.verify(key)) {
                    LicenseManager.Result.Valid -> {
                        VoiceBus.log("TASK", "licence accepted")
                        store.licenseKey = key.trim()
                        store.licenseVerifiedAt = System.currentTimeMillis()
                        onValid()
                    }
                    LicenseManager.Result.Offline -> {
                        message = "Can’t reach the blockchain node. Check your internet and try again."
                        VoiceBus.log("ERR", "licence check: blockchain node unreachable")
                    }
                    is LicenseManager.Result.Invalid -> {
                        message = r.reason
                        VoiceBus.log("ERR", "licence invalid: ${r.reason}")
                    }
                }
                busy = false
            }
        },
    ) { Text(if (busy) "Checking…" else "Verify licence") }
    message?.let { Text(it, color = MaterialTheme.colorScheme.error) }
}

// ───────────────────────── control panel ─────────────────────────

@Composable
private fun ControlScreen(store: SecureStore) {
    val ctx = LocalContext.current
    val a11yOn by VoiceAgentAccessibilityService.connected.collectAsState()
    val running by VoiceListenerService.running.collectAsState()
    val status by VoiceBus.status.collectAsState()

    var micOk by remember { mutableStateOf(has(ctx, Manifest.permission.RECORD_AUDIO)) }
    var notifOk by remember {
        mutableStateOf(Build.VERSION.SDK_INT < 33 || has(ctx, Manifest.permission.POST_NOTIFICATIONS))
    }
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { micOk = it }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { notifOk = it }

    var language by remember { mutableStateOf(store.language) }
    var apiKey by remember { mutableStateOf(store.anthropicKey) }
    var model by remember { mutableStateOf(store.anthropicModel) }
    var shots by remember { mutableStateOf(store.sendScreenshot) }
    val scope = rememberCoroutineScope()
    var wake by remember { mutableStateOf(store.wakeWords) }
    var elevenKey by remember { mutableStateOf(store.elevenKey) }
    var elevenVoice by remember { mutableStateOf(store.elevenVoiceId) }

    Text("Setup", style = MaterialTheme.typography.titleLarge)
    StepRow("Microphone", micOk, "Allow") { micLauncher.launch(Manifest.permission.RECORD_AUDIO) }
    if (Build.VERSION.SDK_INT >= 33) {
        StepRow("Notifications (listening indicator)", notifOk, "Allow") {
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
    StepRow("Accessibility service (lets the agent see and tap)", a11yOn, "Open settings") {
        ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
    if (!a11yOn) {
        Text(
            "Android 13+ may grey the switch out for apps installed from an APK: open Settings › Apps › Voice Agent › ⋮ › " +
                "“Allow restricted settings”, then enable the service.",
            style = MaterialTheme.typography.bodySmall,
        )
    }

    Text("Language", style = MaterialTheme.typography.titleMedium)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("uz" to "O‘zbek", "ru" to "Русский", "en" to "English").forEach { (code, label) ->
            FilterChip(selected = language == code, onClick = { language = code; store.language = code }, label = { Text(label) })
        }
    }
    OutlinedTextField(
        value = wake, onValueChange = { wake = it; store.wakeWords = it },
        label = { Text("Wake words (comma-separated)") }, modifier = Modifier.fillMaxWidth(), singleLine = true,
    )

    if (BuildConfig.BRAIN_BASE_URL.isBlank()) {
        OutlinedTextField(
            value = apiKey, onValueChange = { apiKey = it; store.anthropicKey = it.trim() },
            label = { Text("Anthropic API key") }, placeholder = { Text("sk-ant-api03-…") },
            visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth(), singleLine = true,
        )
    }
    OutlinedTextField(
        value = model, onValueChange = { model = it; store.anthropicModel = it.trim() },
        label = { Text("Model") },
        supportingText = { Text("default: ${SecureStore.DEFAULT_ANTHROPIC_MODEL} · fallback: claude-sonnet-4-20250514") },
        modifier = Modifier.fillMaxWidth(), singleLine = true,
    )
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Column(Modifier.weight(1f)) {
            Text("Send screenshots to the model (vision)")
            Text(
                "Off by default. A screenshot can show passwords and codes that the text view hides. Needs Android 11+.",
                style = MaterialTheme.typography.bodySmall,
            )
        }
        Switch(checked = shots, onCheckedChange = { shots = it; store.sendScreenshot = it })
    }
    OutlinedButton(
        enabled = apiKey.isNotBlank() || BuildConfig.BRAIN_BASE_URL.isNotBlank(),
        modifier = Modifier.fillMaxWidth(),
        onClick = {
            VoiceBus.log("API", "testing connection…")
            scope.launch {
                try {
                    VoiceBus.log("API", ClaudeBrainManager(BrainConfig.from(store)).ping())
                } catch (e: Exception) {
                    VoiceBus.log("ERR", e.message ?: e.javaClass.simpleName)
                }
            }
        },
    ) { Text("Test API connection") }
    OutlinedTextField(
        value = elevenKey, onValueChange = { elevenKey = it; store.elevenKey = it },
        label = { Text("ElevenLabs API key (optional)") }, modifier = Modifier.fillMaxWidth(), singleLine = true,
    )
    OutlinedTextField(
        value = elevenVoice, onValueChange = { elevenVoice = it; store.elevenVoiceId = it },
        label = { Text("ElevenLabs voice ID (optional)") }, modifier = Modifier.fillMaxWidth(), singleLine = true,
    )

    val ready = micOk && a11yOn && (BuildConfig.BRAIN_BASE_URL.isNotBlank() || apiKey.isNotBlank())
    if (running) {
        OutlinedButton(onClick = { VoiceListenerService.stop(ctx) }, modifier = Modifier.fillMaxWidth()) { Text("Stop listening") }
        OutlinedButton(onClick = { VoiceBus.commands.tryEmit("stop") }, modifier = Modifier.fillMaxWidth()) { Text("Stop current task") }
    } else {
        Button(enabled = ready, onClick = { VoiceListenerService.start(ctx) }, modifier = Modifier.fillMaxWidth()) {
            Text("Start listening")
        }
        if (!ready) Text("Finish the setup steps above first.", style = MaterialTheme.typography.bodySmall)
    }
    Text("Status: $status", color = GoldDeep)
}

private val ErrRed = Color(0xFFC62828)
private val MicGreen = Color(0xFF2E7D32)

/**
 * Live log card: what the microphone heard (green), the exact JSON action the model returned (gold),
 * API status (dark), and every error — API, speech, accessibility, TTS — in red.
 * Long-press the text to select / copy a part, or use "Copy log".
 */
@Composable
private fun LogBox() {
    val lines by VoiceBus.logLines.collectAsState()
    val status by VoiceBus.status.collectAsState()
    val clipboard = LocalClipboardManager.current
    val scroll = rememberScrollState()
    LaunchedEffect(lines.size) { scroll.animateScrollTo(scroll.maxValue) }

    val text = buildAnnotatedString {
        if (lines.isEmpty()) append("Nothing yet. Speech text, the model’s JSON, API status and errors will appear here.")
        lines.forEachIndexed { i, line ->
            val color = when {
                line.contains("[ERR]") -> ErrRed
                line.contains("[MIC]") -> MicGreen
                line.contains("[JSON]") -> GoldDeep
                else -> Ink
            }
            withStyle(SpanStyle(color = color)) { append(line) }
            if (i < lines.lastIndex) append("\n")
        }
    }

    Text("Live log", style = MaterialTheme.typography.titleMedium)
    OutlinedCard(Modifier.fillMaxWidth().height(300.dp)) {
        Column(Modifier.fillMaxSize().padding(10.dp)) {
            Text("Status: $status", color = GoldDeep, fontSize = 12.sp)
            SelectionContainer {
                Text(
                    text, fontFamily = FontFamily.Monospace, fontSize = 11.sp,
                    modifier = Modifier.fillMaxWidth().weight(1f).verticalScroll(scroll).padding(top = 6.dp),
                )
            }
        }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedButton(onClick = { clipboard.setText(AnnotatedString(lines.joinToString("\n"))) }) { Text("Copy log") }
        OutlinedButton(onClick = { VoiceBus.clearLog() }) { Text("Clear") }
    }
}

@Composable
private fun StepRow(title: String, done: Boolean, actionLabel: String, onAction: () -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text((if (done) "✓  " else "○  ") + title, color = if (done) GoldDeep else Ink, modifier = Modifier.weight(1f))
        if (!done) TextButton(onClick = onAction) { Text(actionLabel, color = GoldDeep) }
    }
}

// ───────────────────────── permission gate UI ─────────────────────────

/** Tap fallback for the spoken "Yes". Voice answers are handled by PermissionGate itself. */
@Composable
private fun ConfirmationDialog() {
    val pending by VoiceBus.confirmation.collectAsState()
    pending?.let { c ->
        AlertDialog(
            onDismissRequest = { c.answer.complete(false) },
            title = { Text("Confirm action") },
            text = { Text(c.spoken + "\n\n" + c.detail) },
            confirmButton = { Button(onClick = { c.answer.complete(true) }) { Text("Yes") } },
            dismissButton = { OutlinedButton(onClick = { c.answer.complete(false) }) { Text("No") } },
        )
    }
}

private fun has(ctx: Context, permission: String) =
    ContextCompat.checkSelfPermission(ctx, permission) == PackageManager.PERMISSION_GRANTED
