// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/// @dev Minimal ERC-20 surface. Transfers are done through a low-level call (see _safeTransferFrom)
///      because some tokens (e.g. legacy USDT) do not return a bool.
interface IERC20 {
    function decimals() external view returns (uint8);
    function balanceOf(address account) external view returns (uint256);
}

/// @title Marketplace
/// @notice Sells lifetime access to digital products for stablecoins (USDT / USDC) on any EVM chain
///         (Polygon, BNB Chain, ...). Payment goes straight from the buyer to the treasury — the
///         contract never holds funds. A successful purchase emits `AccessGranted`, which the website
///         uses to unlock the APK download and the Android agent uses (via `hasAccess`) to verify a licence.
/// @dev    Prices are stored in USD with 6 decimals ("priceUsd6") and converted to each token's own
///         decimals at purchase time (USDT/USDC have 6 decimals on Polygon but 18 on BNB Chain).
///         1 USDT/USDC is treated as 1 USD.
contract Marketplace {
    /*//////////////////////////////////////////////////////////////
                                 TYPES
    //////////////////////////////////////////////////////////////*/

    struct Product {
        string name;
        uint256 priceUsd6; // e.g. 49_000000 == $49.00
        bool active;
    }

    /*//////////////////////////////////////////////////////////////
                                STORAGE
    //////////////////////////////////////////////////////////////*/

    address public owner;
    address public pendingOwner;
    address public treasury;
    bool public paused;
    uint256 public productCount;

    mapping(uint256 => Product) public products;
    mapping(address => bool) public acceptedToken;
    mapping(address => uint8) public tokenDecimals;
    mapping(address => mapping(uint256 => bool)) private _access; // buyer => productId => owned

    uint256 private _lock = 1; // reentrancy guard

    /*//////////////////////////////////////////////////////////////
                                 EVENTS
    //////////////////////////////////////////////////////////////*/

    /// @notice Emitted whenever `buyer` gains access to `productId` (purchase or owner grant).
    event AccessGranted(address indexed buyer, uint256 indexed productId);
    event AccessRevoked(address indexed buyer, uint256 indexed productId);
    event Purchased(
        address indexed payer,
        address indexed beneficiary,
        uint256 indexed productId,
        address token,
        uint256 amount
    );
    event ProductSet(uint256 indexed productId, string name, uint256 priceUsd6, bool active);
    event TokenSet(address indexed token, bool accepted, uint8 decimals);
    event TreasuryChanged(address indexed treasury);
    event PausedSet(bool paused);
    event OwnershipTransferStarted(address indexed from, address indexed to);
    event OwnershipTransferred(address indexed from, address indexed to);

    /*//////////////////////////////////////////////////////////////
                                 ERRORS
    //////////////////////////////////////////////////////////////*/

    error NotOwner();
    error NotPendingOwner();
    error ZeroAddress();
    error Reentrancy();
    error PausedError();
    error ProductUnavailable();
    error TokenNotAccepted();
    error InvalidToken();
    error AlreadyOwned();
    error TransferFailed();
    error BadPrice();

    /*//////////////////////////////////////////////////////////////
                               MODIFIERS
    //////////////////////////////////////////////////////////////*/

    modifier onlyOwner() {
        if (msg.sender != owner) revert NotOwner();
        _;
    }

    modifier nonReentrant() {
        if (_lock != 1) revert Reentrancy();
        _lock = 2;
        _;
        _lock = 1;
    }

    /*//////////////////////////////////////////////////////////////
                               CONSTRUCTOR
    //////////////////////////////////////////////////////////////*/

    constructor(address treasury_) {
        if (treasury_ == address(0)) revert ZeroAddress();
        owner = msg.sender;
        treasury = treasury_;
        emit OwnershipTransferred(address(0), msg.sender);
        emit TreasuryChanged(treasury_);
    }

    /*//////////////////////////////////////////////////////////////
                               BUYER API
    //////////////////////////////////////////////////////////////*/

    /// @notice Price of `productId` in the smallest unit of `token` (rounded up for tokens with < 6 decimals).
    function quote(uint256 productId, address token) public view returns (uint256) {
        Product storage p = products[productId];
        if (!p.active) revert ProductUnavailable();
        if (!acceptedToken[token]) revert TokenNotAccepted();

        uint8 d = tokenDecimals[token];
        if (d >= 6) return p.priceUsd6 * (uint256(10) ** (d - 6));
        uint256 divisor = uint256(10) ** (6 - d);
        return (p.priceUsd6 + divisor - 1) / divisor;
    }

    /// @notice Buy access for yourself. Requires a prior ERC-20 `approve(marketplace, quote(...))`.
    function purchase(uint256 productId, address token) external {
        _purchase(msg.sender, msg.sender, productId, token);
    }

    /// @notice Buy access for another address (gift).
    function purchaseFor(uint256 productId, address token, address beneficiary) external {
        if (beneficiary == address(0)) revert ZeroAddress();
        _purchase(msg.sender, beneficiary, productId, token);
    }

    /// @notice Used by the website and by the Android licence check.
    function hasAccess(address buyer, uint256 productId) external view returns (bool) {
        return _access[buyer][productId];
    }

    /*//////////////////////////////////////////////////////////////
                               OWNER API
    //////////////////////////////////////////////////////////////*/

    function addProduct(string calldata name, uint256 priceUsd6) external onlyOwner returns (uint256 id) {
        if (priceUsd6 == 0) revert BadPrice();
        id = ++productCount;
        products[id] = Product(name, priceUsd6, true);
        emit ProductSet(id, name, priceUsd6, true);
    }

    function setProduct(uint256 id, string calldata name, uint256 priceUsd6, bool active) external onlyOwner {
        if (id == 0 || id > productCount) revert ProductUnavailable();
        if (priceUsd6 == 0) revert BadPrice();
        products[id] = Product(name, priceUsd6, active);
        emit ProductSet(id, name, priceUsd6, active);
    }

    /// @notice Whitelist or remove a payment token. Decimals are read from the token and cached.
    function setToken(address token, bool accepted) external onlyOwner {
        uint8 d;
        if (accepted) {
            if (token.code.length == 0) revert InvalidToken();
            try IERC20(token).decimals() returns (uint8 dec) {
                if (dec > 36) revert InvalidToken();
                d = dec;
            } catch {
                revert InvalidToken();
            }
            tokenDecimals[token] = d;
        } else {
            d = tokenDecimals[token];
        }
        acceptedToken[token] = accepted;
        emit TokenSet(token, accepted, d);
    }

    function setTreasury(address newTreasury) external onlyOwner {
        if (newTreasury == address(0)) revert ZeroAddress();
        treasury = newTreasury;
        emit TreasuryChanged(newTreasury);
    }

    function setPaused(bool value) external onlyOwner {
        paused = value;
        emit PausedSet(value);
    }

    /// @notice Support / off-chain payment: grant access without payment.
    function grantAccess(address buyer, uint256 productId) external onlyOwner {
        if (buyer == address(0)) revert ZeroAddress();
        if (productId == 0 || productId > productCount) revert ProductUnavailable();
        _access[buyer][productId] = true;
        emit AccessGranted(buyer, productId);
    }

    /// @notice Refund / abuse handling: the Android licence check fails after this.
    function revokeAccess(address buyer, uint256 productId) external onlyOwner {
        _access[buyer][productId] = false;
        emit AccessRevoked(buyer, productId);
    }

    function transferOwnership(address newOwner) external onlyOwner {
        if (newOwner == address(0)) revert ZeroAddress();
        pendingOwner = newOwner;
        emit OwnershipTransferStarted(owner, newOwner);
    }

    function acceptOwnership() external {
        if (msg.sender != pendingOwner) revert NotPendingOwner();
        emit OwnershipTransferred(owner, msg.sender);
        owner = msg.sender;
        pendingOwner = address(0);
    }

    /*//////////////////////////////////////////////////////////////
                               INTERNALS
    //////////////////////////////////////////////////////////////*/

    function _purchase(address payer, address beneficiary, uint256 productId, address token) private nonReentrant {
        if (paused) revert PausedError();
        if (_access[beneficiary][productId]) revert AlreadyOwned();

        uint256 amount = quote(productId, token); // also checks product + token

        // Pay straight to the treasury; verify it really arrived (guards against fee-on-transfer tokens).
        uint256 balBefore = IERC20(token).balanceOf(treasury);
        _safeTransferFrom(token, payer, treasury, amount);
        if (IERC20(token).balanceOf(treasury) - balBefore < amount) revert TransferFailed();

        _access[beneficiary][productId] = true;
        emit Purchased(payer, beneficiary, productId, token, amount);
        emit AccessGranted(beneficiary, productId);
    }

    /// @dev transferFrom that tolerates tokens which return nothing (legacy USDT) and rejects `false`.
    function _safeTransferFrom(address token, address from, address to, uint256 amount) private {
        // bytes4(keccak256("transferFrom(address,address,uint256)")) == 0x23b872dd
        (bool ok, bytes memory ret) = token.call(abi.encodeWithSelector(0x23b872dd, from, to, amount));
        if (!ok || (ret.length != 0 && !abi.decode(ret, (bool)))) revert TransferFailed();
    }
}
